# 🏠 Usta Top Bot

Professional Telegram bot - mijozlar hududidagi ustalarni topishi va ustalar buyurtma olishi uchun.

---

## 📁 Loyiha Strukturasi

```
usta_top/
├── bot.py                    # Asosiy kirish nuqtasi
├── config.py                 # Konfiguratsiya va ma'lumotlar
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── alembic.ini
├── .env.example
│
├── handlers/                 # Handler'lar
│   ├── common.py             # Start, help, orqaga
│   ├── client.py             # Mijoz ro'yxat va buyurtma
│   ├── master.py             # Usta ro'yxat va boshqaruv
│   └── admin.py              # Admin panel
│
├── keyboards/                # Tugmalar
│   ├── reply.py              # Reply keyboard'lar
│   └── inline.py             # Inline keyboard'lar
│
├── database/                 # Ma'lumotlar bazasi
│   ├── models.py             # SQLAlchemy modellari
│   ├── connection.py         # Ulanish
│   └── repositories.py       # Repository pattern
│
├── middlewares/              # O'rta qatlam
│   └── middlewares.py        # DB, bloklash, logging
│
├── filters/                  # Filtrlar
│   └── filters.py            # Admin, master, client filtrlar
│
├── states/                   # FSM holatlar
│   └── states.py             # Barcha state'lar
│
├── services/                 # Xizmatlar
│   └── notification.py       # Xabar yuborish xizmati
│
├── utils/                    # Yordamchi funksiyalar
│   └── formatters.py         # Matn formatlash
│
└── migrations/               # Alembic migratsiyalar
    ├── env.py
    ├── script.py.mako
    └── versions/
        └── 001_initial.py
```

---

## 🗄️ Database Sxemasi

```
users           - Barcha foydalanuvchilar (mijoz, usta, admin)
masters         - Ustalar profili (1:1 users bilan)
orders          - Buyurtmalar
service_types   - Xizmat turlari (admin boshqaradi)
advertisements  - Reklama tarixi
```

---

## 🚀 Ishga Tushirish

### 1️⃣ .env fayl yaratish

```bash
cp .env.example .env
nano .env
```

`.env` ichida:
```env
BOT_TOKEN=7xxxxxxxxx:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
ADMIN_IDS=123456789
DATABASE_URL=postgresql+asyncpg://usta_user:usta_pass@db:5432/usta_top
POSTGRES_DB=usta_top
POSTGRES_USER=usta_user
POSTGRES_PASSWORD=usta_pass
```

### 2️⃣ Docker bilan ishga tushirish (Tavsiya etiladi)

```bash
# Build va ishga tushirish
docker-compose up -d --build

# Log'larni ko'rish
docker-compose logs -f bot

# To'xtatish
docker-compose down
```

### 3️⃣ Local ishga tushirish (Development)

```bash
# Virtual muhit
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Kutubxonalar
pip install -r requirements.txt

# Database migratsiya
alembic upgrade head

# Botni ishga tushirish
python bot.py
```

---

## ☁️ Deployment (VPS/Server)

### Railway.app (Bepul tier bor)

1. [railway.app](https://railway.app) ga kiring
2. New Project → Deploy from GitHub repo
3. PostgreSQL plugin qo'shing
4. Environment variables qo'shing
5. Deploy!

### Render.com

1. [render.com](https://render.com) ga kiring
2. New → Web Service → Connect GitHub
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `alembic upgrade head && python bot.py`
5. Add PostgreSQL database
6. Environment variables qo'shing

### VPS (DigitalOcean, Hetzner, va boshqalar)

```bash
# Server tayyorlash
apt update && apt install -y docker.io docker-compose git

# Repo klonlash
git clone <your-repo-url>
cd usta_top

# .env sozlash
cp .env.example .env
nano .env

# Ishga tushirish
docker-compose up -d --build

# Auto-restart uchun systemd
# (ixtiyoriy - docker-compose restart: unless-stopped allaqachon bor)
```

---

## ⚠️ MUHIM ESLATMA: Netlify haqida

> **Netlify Telegram bot uchun mos EMAS!**
> 
> Netlify faqat **statik saytlar** va **serverless functions** uchun mo'ljallangan.
> Telegram bot esa **doimiy ulanish** (long polling) talab qiladi.
> 
> ✅ **To'g'ri tanlovlar:**
> - Railway.app (bepul, oson)
> - Render.com (bepul tier bor)
> - Heroku
> - DigitalOcean / Hetzner VPS
> - O'zingizning server

---

## 📱 Bot Funksiyalari

### 👤 Mijoz
- `/start` → Ro'yxatdan o'tish
- 📋 Buyurtma berish → Xizmat tanlash → Hudud → Tavsif → Rasm (ixtiyoriy)
- 📜 Buyurtmalarim → Barcha buyurtmalar tarixi

### 🔧 Usta
- 🔧 Usta bo'lish → Ro'yxatdan o'tish (admin tasdiqlaydi)
- 📋 Buyurtmalar → Hududidagi buyurtmalar
- 👤 Profilim → Profil ma'lumotlari
- 📊 Statistika → Buyurtmalar soni, reyting

### 👮 Admin
- 👮 Admin panel → Bosh panel
- Ustalar tasdiqlaish/rad etish
- Foydalanuvchilarni bloklash
- 📊 Statistika
- 🛠️ Xizmat turlarini boshqarish
- 📢 Reklama yuborish

---

## 🛠️ Texnik Ma'lumotlar

| Texnologiya | Versiya |
|-------------|---------|
| Python | 3.12 |
| Aiogram | 3.13+ |
| SQLAlchemy | 2.0+ |
| Alembic | 1.14+ |
| PostgreSQL | 16 |

---

## 📞 Murojaat

Savollar uchun: @your_support_username
