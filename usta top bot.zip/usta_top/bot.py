import asyncio
import logging
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import config
from middlewares import DatabaseMiddleware, BlockedUserMiddleware, LoggingMiddleware
from handlers import common, client, master, admin

# ─── Logging sozlash ──────────────────────────────────────────────────────────

Path("logs").mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/bot.log", encoding="utf-8"),
    ],
)

logger = logging.getLogger(__name__)


# ─── Bot & Dispatcher ─────────────────────────────────────────────────────────

async def create_bot() -> tuple[Bot, Dispatcher]:
    bot = Bot(
        token=config.bot.token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )

    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    # Middlewares
    dp.message.middleware(LoggingMiddleware())
    dp.message.middleware(DatabaseMiddleware())
    dp.message.middleware(BlockedUserMiddleware())

    dp.callback_query.middleware(LoggingMiddleware())
    dp.callback_query.middleware(DatabaseMiddleware())
    dp.callback_query.middleware(BlockedUserMiddleware())

    # Routers - tartib muhim!
    dp.include_router(admin.router)    # Admin handler birinchi (filter bilan)
    dp.include_router(master.router)   # Master handler ikkinchi
    dp.include_router(client.router)   # Client handler uchinchi
    dp.include_router(common.router)   # Umumiy handler oxirida

    return bot, dp


async def on_startup(bot: Bot):
    logger.info("Bot ishga tushdi!")
    logger.info(f"Bot nomi: {config.bot.name}")
    logger.info(f"Admin IDs: {config.bot.admin_ids}")

    # Media papka yaratish
    Path(config.bot.media_dir).mkdir(exist_ok=True)

    # Adminlarga xabar yuborish
    for admin_id in config.bot.admin_ids:
        try:
            await bot.send_message(
                admin_id,
                f"🤖 <b>{config.bot.name}</b> boti ishga tushdi!\n\n"
                f"✅ Tizim tayyor.",
            )
        except Exception as e:
            logger.warning(f"Failed to notify admin {admin_id}: {e}")


async def on_shutdown(bot: Bot):
    logger.info("Bot to'xtatilmoqda...")
    for admin_id in config.bot.admin_ids:
        try:
            await bot.send_message(admin_id, "🔴 Bot to'xtatildi.")
        except Exception:
            pass


async def main():
    if not config.bot.token:
        logger.error("BOT_TOKEN topilmadi! .env faylini tekshiring.")
        sys.exit(1)

    bot, dp = await create_bot()

    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    logger.info("Polling boshlandi...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
