import os
from dataclasses import dataclass, field
from typing import List
from dotenv import load_dotenv

load_dotenv()


@dataclass
class DatabaseConfig:
    url: str = field(default_factory=lambda: os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://usta_user:usta_pass@localhost:5432/usta_top"
    ))
    pool_size: int = 10
    max_overflow: int = 20
    echo: bool = False


@dataclass
class BotConfig:
    token: str = field(default_factory=lambda: os.getenv("BOT_TOKEN", ""))
    admin_ids: List[int] = field(default_factory=lambda: [
        int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()
    ])
    name: str = field(default_factory=lambda: os.getenv("BOT_NAME", "Usta Top"))
    support_username: str = field(default_factory=lambda: os.getenv("SUPPORT_USERNAME", "@support"))
    media_dir: str = field(default_factory=lambda: os.getenv("MEDIA_DIR", "media"))


@dataclass
class Config:
    bot: BotConfig = field(default_factory=BotConfig)
    db: DatabaseConfig = field(default_factory=DatabaseConfig)


config = Config()

# Viloyatlar
REGIONS = [
    "Toshkent shahri",
    "Toshkent viloyati",
    "Andijon",
    "Farg'ona",
    "Namangan",
    "Samarqand",
    "Buxoro",
    "Navoiy",
    "Qashqadaryo",
    "Surxondaryo",
    "Jizzax",
    "Sirdaryo",
    "Xorazm",
    "Qoraqalpog'iston",
]

# Tumanlar (viloyat -> tumanlar)
DISTRICTS = {
    "Toshkent shahri": [
        "Bektemir", "Chilonzor", "Hamza", "Mirobod", "Mirzo Ulug'bek",
        "Olmazor", "Sergeli", "Shayxontohur", "Uchtepa", "Yakkasaroy",
        "Yunusobod", "Yashnobod"
    ],
    "Toshkent viloyati": [
        "Angren", "Bekobod", "Bo'stonliq", "Bo'ka", "Chinoz",
        "Qibray", "Ohangaron", "Oqqo'rg'on", "Parkent", "Piskent",
        "Toyloq", "Toshkent tumani", "Yangiyo'l", "Yuqorichirchiq",
        "Zangiota", "Zangota"
    ],
    "Andijon": [
        "Andijon shahri", "Asaka", "Baliqchi", "Bo'z", "Buloqboshi",
        "Hojaobod", "Izboskan", "Jalolquduq", "Xo'jaobod", "Marhamat",
        "Oltinkol", "Paxtaobod", "Qo'rg'ontepa", "Shahrixon", "Ulug'nor"
    ],
    "Farg'ona": [
        "Farg'ona shahri", "Bag'dod", "Beshariq", "Buvayda", "Dang'ara",
        "Furqat", "Hamza", "Qo'shtepa", "Quva", "Oltiariq",
        "O'zbekiston", "Rishton", "So'x", "Toshloq", "Uchko'prik",
        "Yozyovon"
    ],
    "Namangan": [
        "Namangan shahri", "Chortoq", "Chust", "Kosonsoy", "Mingbuloq",
        "Namangan tumani", "Norin", "Pop", "To'raqo'rg'on", "Uychi",
        "Yangi qo'rg'on"
    ],
    "Samarqand": [
        "Samarqand shahri", "Bulung'ur", "Ishtixon", "Jomboy", "Kattaqo'rg'on",
        "Narpay", "Nurobod", "Oqdaryo", "Pastdarg'om", "Paxtachi",
        "Payariq", "Qo'shrabot", "Toyloq", "Urgut"
    ],
    "Buxoro": [
        "Buxoro shahri", "G'ijduvon", "Jondor", "Kogon", "Qorako'l",
        "Qorovulbozor", "Olot", "Peshku", "Romitan", "Shofirkon",
        "Vobkent"
    ],
    "Navoiy": [
        "Navoiy shahri", "Karmana", "Konimex", "Navbahor", "Nurota",
        "Qiziltepa", "Tomdi", "Uchquduq", "Xatirchi"
    ],
    "Qashqadaryo": [
        "Qarshi shahri", "Chiroqchi", "Dehqonobod", "G'uzor", "Kasbi",
        "Kitob", "Koson", "Mirishkor", "Muborak", "Nishon",
        "Qamashi", "Shahrisabz", "Yakkabog'"
    ],
    "Surxondaryo": [
        "Termiz shahri", "Angor", "Bandixon", "Boysun", "Denov",
        "Jarqo'rg'on", "Muzrabot", "Oltinsoy", "Qiziriq", "Qumqo'rg'on",
        "Sariosiyo", "Sherobod", "Sho'rchi", "Uzun"
    ],
    "Jizzax": [
        "Jizzax shahri", "Arnasoy", "Baxmal", "Do'stlik", "Forish",
        "G'allaorol", "Mirzacho'l", "Paxtakor", "Yangiobod", "Zarbdor",
        "Zafarobod", "Zomin"
    ],
    "Sirdaryo": [
        "Guliston shahri", "Boyovut", "Guliston tumani", "Hovos",
        "Mirzaobod", "Oqoltin", "Sardoba", "Sayxunobod",
        "Shirin", "Xovos"
    ],
    "Xorazm": [
        "Urganch shahri", "Bog'ot", "Gurlan", "Xiva", "Xonqa",
        "Qo'shko'pir", "Shovot", "Tuproqqal'a", "Yangiariq", "Yangibozor"
    ],
    "Qoraqalpog'iston": [
        "Nukus shahri", "Amudaryo", "Beruniy", "Bo'zatov", "Chimboy",
        "Ellikqal'a", "Kegeyli", "Mo'ynoq", "Nukus tumani", "Qanliko'l",
        "Qo'ng'irot", "Qorao'zak", "Shumanay", "Taxtako'pir",
        "To'rtko'l", "Xo'jayli"
    ],
}

# Xizmat turlari
SERVICE_TYPES = [
    "🔌 Elektrik",
    "🔧 Santexnik",
    "🏗️ Qurilish",
    "🪟 Deraza va eshik",
    "🎨 Bo'yoqchi",
    "❄️ Konditsioner",
    "📺 Elektronika ta'miri",
    "🚿 Vannaxona ta'miri",
    "🪴 Dacha va bog'",
    "🚗 Avto ta'mir",
    "🏠 Uy tozalash",
    "🔑 Qulfchilik",
    "📦 Ko'chirish",
    "🛋️ Mebel yig'ish",
    "💻 Kompyuter ta'miri",
    "📡 Antenn va internet",
    "🧱 G'isht ishlari",
    "🪚 Yog'ochchilik",
    "🌡️ Gaz ishlari",
    "🏊 Hovuz ta'miri",
]
