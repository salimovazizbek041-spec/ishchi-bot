from datetime import datetime
from enum import Enum as PyEnum
from typing import Optional, List

from sqlalchemy import (
    BigInteger, String, Text, Boolean, DateTime, ForeignKey,
    Enum, Integer, Float, func
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class UserRole(str, PyEnum):
    CLIENT = "client"
    MASTER = "master"
    ADMIN = "admin"


class OrderStatus(str, PyEnum):
    PENDING = "pending"       # Kutilmoqda
    ACCEPTED = "accepted"     # Qabul qilindi
    IN_PROGRESS = "in_progress"  # Bajarilmoqda
    COMPLETED = "completed"   # Bajarildi
    CANCELLED = "cancelled"   # Bekor qilindi


class MasterStatus(str, PyEnum):
    PENDING = "pending"       # Tasdiqlanmagan
    APPROVED = "approved"     # Tasdiqlangan
    BLOCKED = "blocked"       # Bloklangan


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(255))
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    username: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.CLIENT)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    region: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    district: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    orders: Mapped[List["Order"]] = relationship(
        "Order", back_populates="client", foreign_keys="Order.client_id"
    )
    master_profile: Mapped[Optional["Master"]] = relationship(
        "Master", back_populates="user", uselist=False
    )


class Master(Base):
    __tablename__ = "masters"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), unique=True)
    service_type: Mapped[str] = mapped_column(String(100))
    region: Mapped[str] = mapped_column(String(100))
    district: Mapped[str] = mapped_column(String(100))
    experience: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    price_from: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    price_to: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[MasterStatus] = mapped_column(Enum(MasterStatus), default=MasterStatus.PENDING)
    rating: Mapped[float] = mapped_column(Float, default=0.0)
    total_orders: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="master_profile")
    accepted_orders: Mapped[List["Order"]] = relationship(
        "Order", back_populates="master", foreign_keys="Order.master_id"
    )


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    client_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"))
    master_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("masters.id"), nullable=True
    )
    service_type: Mapped[str] = mapped_column(String(100))
    region: Mapped[str] = mapped_column(String(100))
    district: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    photo_file_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    status: Mapped[OrderStatus] = mapped_column(Enum(OrderStatus), default=OrderStatus.PENDING)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    client: Mapped["User"] = relationship(
        "User", back_populates="orders", foreign_keys=[client_id]
    )
    master: Mapped[Optional["Master"]] = relationship(
        "Master", back_populates="accepted_orders", foreign_keys=[master_id]
    )


class ServiceType(Base):
    __tablename__ = "service_types"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    emoji: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Advertisement(Base):
    __tablename__ = "advertisements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    text: Mapped[str] = mapped_column(Text)
    photo_file_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    sent_count: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
