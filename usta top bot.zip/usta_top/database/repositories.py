from typing import Optional, List, Sequence
from sqlalchemy import select, update, delete, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import User, Master, Order, ServiceType, Advertisement, UserRole, MasterStatus, OrderStatus


# ─── User Repository ───────────────────────────────────────────────────────────

class UserRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def create(self, telegram_id: int, full_name: str, username: Optional[str] = None) -> User:
        user = User(
            telegram_id=telegram_id,
            full_name=full_name,
            username=username,
        )
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def update(self, telegram_id: int, **kwargs) -> Optional[User]:
        await self.session.execute(
            update(User).where(User.telegram_id == telegram_id).values(**kwargs)
        )
        await self.session.commit()
        return await self.get_by_telegram_id(telegram_id)

    async def get_all(self, limit: int = 100, offset: int = 0) -> Sequence[User]:
        result = await self.session.execute(
            select(User).limit(limit).offset(offset).order_by(User.created_at.desc())
        )
        return result.scalars().all()

    async def count(self) -> int:
        result = await self.session.execute(select(func.count(User.id)))
        return result.scalar_one()

    async def block(self, telegram_id: int, is_blocked: bool = True):
        await self.session.execute(
            update(User).where(User.telegram_id == telegram_id).values(is_blocked=is_blocked)
        )
        await self.session.commit()


# ─── Master Repository ─────────────────────────────────────────────────────────

class MasterRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_user_id(self, user_id: int) -> Optional[Master]:
        result = await self.session.execute(
            select(Master)
            .where(Master.user_id == user_id)
            .options(selectinload(Master.user))
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, master_id: int) -> Optional[Master]:
        result = await self.session.execute(
            select(Master)
            .where(Master.id == master_id)
            .options(selectinload(Master.user))
        )
        return result.scalar_one_or_none()

    async def create(self, user_id: int, service_type: str, region: str,
                     district: str, experience: Optional[str] = None,
                     price_from: Optional[float] = None, price_to: Optional[float] = None,
                     description: Optional[str] = None) -> Master:
        master = Master(
            user_id=user_id,
            service_type=service_type,
            region=region,
            district=district,
            experience=experience,
            price_from=price_from,
            price_to=price_to,
            description=description,
        )
        self.session.add(master)
        await self.session.commit()
        await self.session.refresh(master)
        return master

    async def update(self, master_id: int, **kwargs) -> Optional[Master]:
        await self.session.execute(
            update(Master).where(Master.id == master_id).values(**kwargs)
        )
        await self.session.commit()
        return await self.get_by_id(master_id)

    async def get_pending(self) -> Sequence[Master]:
        result = await self.session.execute(
            select(Master)
            .where(Master.status == MasterStatus.PENDING)
            .options(selectinload(Master.user))
            .order_by(Master.created_at.desc())
        )
        return result.scalars().all()

    async def get_approved_by_service_region(
        self, service_type: str, region: str, district: Optional[str] = None
    ) -> Sequence[Master]:
        conditions = [
            Master.status == MasterStatus.APPROVED,
            Master.service_type == service_type,
            Master.region == region,
        ]
        if district:
            conditions.append(Master.district == district)
        result = await self.session.execute(
            select(Master)
            .where(and_(*conditions))
            .options(selectinload(Master.user))
            .order_by(Master.rating.desc())
        )
        return result.scalars().all()

    async def count(self, status: Optional[MasterStatus] = None) -> int:
        q = select(func.count(Master.id))
        if status:
            q = q.where(Master.status == status)
        result = await self.session.execute(q)
        return result.scalar_one()

    async def approve(self, master_id: int):
        await self.session.execute(
            update(Master).where(Master.id == master_id).values(status=MasterStatus.APPROVED)
        )
        await self.session.commit()

    async def reject(self, master_id: int):
        await self.session.execute(
            update(Master).where(Master.id == master_id).values(status=MasterStatus.BLOCKED)
        )
        await self.session.commit()


# ─── Order Repository ──────────────────────────────────────────────────────────

class OrderRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, client_id: int, service_type: str, region: str,
                     district: str, description: str,
                     photo_file_id: Optional[str] = None) -> Order:
        order = Order(
            client_id=client_id,
            service_type=service_type,
            region=region,
            district=district,
            description=description,
            photo_file_id=photo_file_id,
        )
        self.session.add(order)
        await self.session.commit()
        await self.session.refresh(order)
        return order

    async def get_by_id(self, order_id: int) -> Optional[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.id == order_id)
            .options(
                selectinload(Order.client),
                selectinload(Order.master).selectinload(Master.user)
            )
        )
        return result.scalar_one_or_none()

    async def get_by_client(self, client_id: int) -> Sequence[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.client_id == client_id)
            .order_by(Order.created_at.desc())
        )
        return result.scalars().all()

    async def get_by_master(self, master_id: int) -> Sequence[Order]:
        result = await self.session.execute(
            select(Order)
            .where(Order.master_id == master_id)
            .options(selectinload(Order.client))
            .order_by(Order.created_at.desc())
        )
        return result.scalars().all()

    async def get_pending_by_region(self, service_type: str, region: str,
                                    district: str) -> Sequence[Order]:
        result = await self.session.execute(
            select(Order)
            .where(and_(
                Order.status == OrderStatus.PENDING,
                Order.service_type == service_type,
                Order.region == region,
                Order.district == district,
            ))
            .options(selectinload(Order.client))
            .order_by(Order.created_at.desc())
            .limit(10)
        )
        return result.scalars().all()

    async def update_status(self, order_id: int, status: OrderStatus,
                            master_id: Optional[int] = None):
        values = {"status": status}
        if master_id is not None:
            values["master_id"] = master_id
        await self.session.execute(
            update(Order).where(Order.id == order_id).values(**values)
        )
        await self.session.commit()

    async def count(self, status: Optional[OrderStatus] = None) -> int:
        q = select(func.count(Order.id))
        if status:
            q = q.where(Order.status == status)
        result = await self.session.execute(q)
        return result.scalar_one()


# ─── Service Type Repository ───────────────────────────────────────────────────

class ServiceTypeRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_all_active(self) -> Sequence[ServiceType]:
        result = await self.session.execute(
            select(ServiceType).where(ServiceType.is_active == True).order_by(ServiceType.name)
        )
        return result.scalars().all()

    async def get_all(self) -> Sequence[ServiceType]:
        result = await self.session.execute(
            select(ServiceType).order_by(ServiceType.created_at.desc())
        )
        return result.scalars().all()

    async def create(self, name: str, emoji: Optional[str] = None) -> ServiceType:
        stype = ServiceType(name=name, emoji=emoji)
        self.session.add(stype)
        await self.session.commit()
        await self.session.refresh(stype)
        return stype

    async def delete(self, service_id: int):
        await self.session.execute(
            delete(ServiceType).where(ServiceType.id == service_id)
        )
        await self.session.commit()

    async def toggle(self, service_id: int, is_active: bool):
        await self.session.execute(
            update(ServiceType).where(ServiceType.id == service_id).values(is_active=is_active)
        )
        await self.session.commit()


# ─── Repository Factory ────────────────────────────────────────────────────────

class Repositories:
    def __init__(self, session: AsyncSession):
        self.users = UserRepo(session)
        self.masters = MasterRepo(session)
        self.orders = OrderRepo(session)
        self.services = ServiceTypeRepo(session)
        self._session = session
