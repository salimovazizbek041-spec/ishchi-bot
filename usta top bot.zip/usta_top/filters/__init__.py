from filters.filters import IsAdmin, IsMaster, IsClient, IsRegistered

__all__ = ["IsAdmin", "IsMaster", "IsClient", "IsRegistered"]
