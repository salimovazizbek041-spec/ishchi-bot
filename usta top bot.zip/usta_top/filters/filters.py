from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery

from config import config
from database.models import UserRole


class IsAdmin(BaseFilter):
    """Faqat admin foydalanuvchilar uchun filter."""

    async def __call__(self, event: Message | CallbackQuery) -> bool:
        user_id = event.from_user.id if event.from_user else 0
        return user_id in config.bot.admin_ids


class IsMaster(BaseFilter):
    """Faqat ustalar uchun filter."""

    async def __call__(self, event: Message | CallbackQuery, db_user=None) -> bool:
        if not db_user:
            return False
        return db_user.role == UserRole.MASTER


class IsClient(BaseFilter):
    """Faqat mijozlar uchun filter."""

    async def __call__(self, event: Message | CallbackQuery, db_user=None) -> bool:
        if not db_user:
            return True  # Yangi foydalanuvchi ham client hisoblansa
        return db_user.role == UserRole.CLIENT


class IsRegistered(BaseFilter):
    """Ro'yxatdan o'tgan foydalanuvchilar uchun filter."""

    async def __call__(self, event: Message | CallbackQuery, db_user=None) -> bool:
        return db_user is not None and db_user.phone is not None
