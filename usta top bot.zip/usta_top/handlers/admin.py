import logging

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from database.models import OrderStatus, MasterStatus
from database.repositories import Repositories
from filters.filters import IsAdmin
from keyboards.inline import (
    get_admin_panel_keyboard, get_master_approval_keyboard,
    get_pending_masters_keyboard, get_services_admin_keyboard
)
from keyboards.reply import get_main_menu_admin, get_cancel_keyboard
from services.notification import NotificationService
from states.states import AdminStates
from utils.formatters import format_master_profile, format_stats, format_user_info

logger = logging.getLogger(__name__)
router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


# ─── Admin Panel Entry ─────────────────────────────────────────────────────────

@router.message(F.text == "👮 Admin panel")
@router.message(Command("admin"))
async def admin_panel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "👮 <b>Admin Panel</b>\n\nQuyidagi amallardan birini tanlang:",
        parse_mode="HTML",
        reply_markup=get_admin_panel_keyboard()
    )


# ─── Statistics ────────────────────────────────────────────────────────────────

@router.message(F.text == "📊 Statistika")
@router.callback_query(F.data == "admin:stats")
async def admin_stats(event: Message | CallbackQuery, repo: Repositories):
    total_users = await repo.users.count()
    total_masters = await repo.masters.count()
    pending_masters = await repo.masters.count(MasterStatus.PENDING)
    total_orders = await repo.orders.count()
    pending_orders = await repo.orders.count(OrderStatus.PENDING)
    completed_orders = await repo.orders.count(OrderStatus.COMPLETED)

    text = format_stats(
        total_users, total_masters, pending_masters,
        total_orders, pending_orders, completed_orders
    )

    if isinstance(event, CallbackQuery):
        await event.message.edit_text(text, parse_mode="HTML", reply_markup=get_admin_panel_keyboard())
        await event.answer()
    else:
        await event.answer(text, parse_mode="HTML")


# ─── Pending Masters ───────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:pending_masters")
async def pending_masters(callback: CallbackQuery, repo: Repositories):
    masters = await repo.masters.get_pending()

    if not masters:
        await callback.message.edit_text(
            "✅ Tasdiqlanmagan ustalar yo'q.",
            reply_markup=get_admin_panel_keyboard()
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        f"⏳ <b>Tasdiq kutayotgan ustalar ({len(masters)} ta):</b>",
        parse_mode="HTML",
        reply_markup=get_pending_masters_keyboard(masters)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("view_master:"))
async def view_master(callback: CallbackQuery, repo: Repositories):
    master_id = int(callback.data.split(":")[1])
    master = await repo.masters.get_by_id(master_id)

    if not master:
        await callback.answer("❌ Usta topilmadi!", show_alert=True)
        return

    await callback.message.answer(
        format_master_profile(master),
        parse_mode="HTML",
        reply_markup=get_master_approval_keyboard(master_id)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("approve_master:"))
async def approve_master(callback: CallbackQuery, repo: Repositories):
    master_id = int(callback.data.split(":")[1])
    master = await repo.masters.get_by_id(master_id)

    if not master:
        await callback.answer("❌ Usta topilmadi!", show_alert=True)
        return

    await repo.masters.approve(master_id)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(f"✅ Usta <b>{master.user.full_name}</b> tasdiqlandi!", parse_mode="HTML")

    notification_service = NotificationService(callback.bot)
    full_master = await repo.masters.get_by_id(master_id)
    await notification_service.notify_master_approved(full_master)
    await callback.answer("✅ Tasdiqlandi!")


@router.callback_query(F.data.startswith("reject_master:"))
async def reject_master(callback: CallbackQuery, repo: Repositories):
    master_id = int(callback.data.split(":")[1])
    master = await repo.masters.get_by_id(master_id)

    if not master:
        await callback.answer("❌ Usta topilmadi!", show_alert=True)
        return

    await repo.masters.reject(master_id)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(f"❌ Usta <b>{master.user.full_name}</b> rad etildi!", parse_mode="HTML")

    notification_service = NotificationService(callback.bot)
    full_master = await repo.masters.get_by_id(master_id)
    await notification_service.notify_master_rejected(full_master)
    await callback.answer("❌ Rad etildi!")


# ─── Broadcast ─────────────────────────────────────────────────────────────────

@router.message(F.text == "📢 Reklama")
@router.callback_query(F.data == "admin:broadcast")
async def start_broadcast(event: Message | CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.waiting_broadcast_text)
    text = "📢 <b>Reklama matni kiriting:</b>"

    if isinstance(event, CallbackQuery):
        await event.message.answer(text, parse_mode="HTML", reply_markup=get_cancel_keyboard())
        await event.answer()
    else:
        await event.answer(text, parse_mode="HTML", reply_markup=get_cancel_keyboard())


@router.message(AdminStates.waiting_broadcast_text, F.text)
async def broadcast_text(message: Message, state: FSMContext):
    await state.update_data(broadcast_text=message.text)
    await message.answer(
        "📸 Rasm yuborasizmi? (Ixtiyoriy - o'tkazib yuborish uchun /skip)",
        reply_markup=get_cancel_keyboard()
    )
    await state.set_state(AdminStates.waiting_broadcast_photo)


@router.message(AdminStates.waiting_broadcast_photo, F.photo)
async def broadcast_with_photo(message: Message, state: FSMContext, repo: Repositories):
    photo_id = message.photo[-1].file_id
    data = await state.get_data()
    await _send_broadcast(message, state, repo, data.get("broadcast_text"), photo_id)


@router.message(AdminStates.waiting_broadcast_photo, F.text == "/skip")
async def broadcast_without_photo(message: Message, state: FSMContext, repo: Repositories):
    data = await state.get_data()
    await _send_broadcast(message, state, repo, data.get("broadcast_text"), None)


async def _send_broadcast(message: Message, state: FSMContext, repo: Repositories,
                           text: str, photo_id):
    await state.clear()
    users = await repo.users.get_all(limit=10000)

    await message.answer(f"⏳ Reklama {len(users)} ta foydalanuvchiga yuborilmoqda...")

    notification_service = NotificationService(message.bot)
    sent, failed = await notification_service.broadcast(users, text, photo_id)

    await message.answer(
        f"✅ <b>Reklama yuborildi!</b>\n\n"
        f"✔️ Muvaffaqiyatli: {sent}\n"
        f"❌ Xatolik: {failed}",
        parse_mode="HTML",
        reply_markup=get_main_menu_admin()
    )


# ─── Block User ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:block_user")
async def block_user_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.waiting_block_user_id)
    await callback.message.answer(
        "🚫 Bloklamoqchi bo'lgan foydalanuvchining Telegram ID sini kiriting:",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()


@router.message(AdminStates.waiting_block_user_id, F.text)
async def block_user_execute(message: Message, state: FSMContext, repo: Repositories):
    try:
        user_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Noto'g'ri ID! Raqam kiriting:")
        return

    user = await repo.users.get_by_telegram_id(user_id)
    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi!")
        return

    new_status = not user.is_blocked
    await repo.users.block(user_id, new_status)
    await state.clear()

    action = "bloklandi 🚫" if new_status else "blokdan chiqarildi ✅"
    await message.answer(
        f"👤 <b>{user.full_name}</b> {action}",
        parse_mode="HTML",
        reply_markup=get_main_menu_admin()
    )


# ─── Service Types Management ──────────────────────────────────────────────────

@router.callback_query(F.data == "admin:services")
async def manage_services(callback: CallbackQuery, repo: Repositories):
    services = await repo.services.get_all()
    if not services:
        await callback.message.edit_text(
            "🛠️ Xizmat turlari yo'q. Yangi qo'shing:",
            reply_markup=get_services_admin_keyboard([])
        )
    else:
        await callback.message.edit_text(
            "🛠️ <b>Xizmat turlari boshqaruvi:</b>",
            parse_mode="HTML",
            reply_markup=get_services_admin_keyboard(services)
        )
    await callback.answer()


@router.callback_query(F.data == "admin:add_service")
async def add_service_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.waiting_service_name)
    await callback.message.answer(
        "➕ Yangi xizmat nomini kiriting (emoji bilan):\n"
        "Masalan: 🏊 Havuz ta'miri",
        reply_markup=get_cancel_keyboard()
    )
    await callback.answer()


@router.message(AdminStates.waiting_service_name, F.text)
async def add_service_execute(message: Message, state: FSMContext, repo: Repositories):
    name = message.text.strip()
    await repo.services.create(name=name)
    await state.clear()
    await message.answer(
        f"✅ Xizmat qo'shildi: <b>{name}</b>",
        parse_mode="HTML",
        reply_markup=get_main_menu_admin()
    )


@router.callback_query(F.data.startswith("toggle_service:"))
async def toggle_service(callback: CallbackQuery, repo: Repositories):
    parts = callback.data.split(":")
    service_id = int(parts[1])
    new_status = bool(int(parts[2]))

    await repo.services.toggle(service_id, new_status)
    services = await repo.services.get_all()
    await callback.message.edit_reply_markup(
        reply_markup=get_services_admin_keyboard(services)
    )
    await callback.answer("✅ Holat yangilandi!")


@router.callback_query(F.data == "admin:back")
async def admin_back(callback: CallbackQuery):
    await callback.message.edit_text(
        "👮 <b>Admin Panel</b>",
        parse_mode="HTML",
        reply_markup=get_admin_panel_keyboard()
    )
    await callback.answer()


# ─── Users List ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:users")
async def admin_users(callback: CallbackQuery, repo: Repositories):
    total = await repo.users.count()
    users = await repo.users.get_all(limit=10)

    text = f"👥 <b>Foydalanuvchilar (Jami: {total})</b>\n\n"
    for user in users:
        blocked = " 🚫" if user.is_blocked else ""
        text += f"• {user.full_name}{blocked} - <code>{user.telegram_id}</code>\n"

    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_panel_keyboard()
    )
    await callback.answer()
