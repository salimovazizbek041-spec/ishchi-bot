import logging

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from config import REGIONS, DISTRICTS, SERVICE_TYPES
from database.models import UserRole
from database.repositories import Repositories
from keyboards.reply import (
    get_phone_keyboard, get_regions_keyboard, get_districts_keyboard,
    get_services_keyboard, get_skip_keyboard, get_confirm_keyboard,
    get_main_menu_client, get_cancel_keyboard
)
from services.notification import NotificationService
from states.states import ClientRegisterStates, OrderCreateStates
from utils.formatters import format_order_info

logger = logging.getLogger(__name__)
router = Router()


# ─── Client Registration ───────────────────────────────────────────────────────

@router.message(F.text == "🔧 Usta bo'lish")
async def become_master_redirect(message: Message):
    """Bu handleri master handler ushlab oladi, bu yerda faqat hijack oldini olish."""
    pass


@router.message(F.text == "📋 Buyurtma berish")
async def start_order(message: Message, state: FSMContext, db_user=None, repo: Repositories = None):
    """Buyurtma berish - avval ro'yxatdan o'tish kerak."""
    if not db_user or not db_user.phone:
        # Ro'yxatdan o'tmagan - avval ro'yxat
        await message.answer(
            "📝 Buyurtma berish uchun avval ro'yxatdan o'tishingiz kerak.\n\n"
            "Ismingizni kiriting:",
            reply_markup=get_cancel_keyboard()
        )
        await state.set_state(ClientRegisterStates.waiting_name)
        await state.update_data(next_action="order")
        return

    # Ro'yxatdan o'tgan - to'g'ridan buyurtma
    await message.answer(
        "🛠️ Kerakli xizmat turini tanlang:",
        reply_markup=get_services_keyboard()
    )
    await state.set_state(OrderCreateStates.waiting_service)


@router.message(ClientRegisterStates.waiting_name)
async def register_name(message: Message, state: FSMContext):
    if not message.text or len(message.text) < 2:
        await message.answer("❌ Iltimos, to'g'ri ism kiriting:")
        return

    await state.update_data(full_name=message.text.strip())
    await message.answer(
        "📱 Telefon raqamingizni yuboring:",
        reply_markup=get_phone_keyboard()
    )
    await state.set_state(ClientRegisterStates.waiting_phone)


@router.message(ClientRegisterStates.waiting_phone, F.contact)
async def register_phone_contact(message: Message, state: FSMContext, repo: Repositories, db_user=None):
    phone = message.contact.phone_number
    if not phone.startswith("+"):
        phone = "+" + phone
    await _save_client_phone(message, state, repo, phone, db_user)


@router.message(ClientRegisterStates.waiting_phone, F.text)
async def register_phone_text(message: Message, state: FSMContext, repo: Repositories, db_user=None):
    phone = message.text.strip()
    if not phone.replace("+", "").replace(" ", "").isdigit() or len(phone) < 9:
        await message.answer("❌ Noto'g'ri raqam! Qaytadan kiriting:")
        return
    await _save_client_phone(message, state, repo, phone, db_user)


async def _save_client_phone(message: Message, state: FSMContext, repo: Repositories, phone: str, db_user):
    data = await state.get_data()
    full_name = data.get("full_name", message.from_user.full_name)
    next_action = data.get("next_action")

    await repo.users.update(
        message.from_user.id,
        full_name=full_name,
        phone=phone,
        role=UserRole.CLIENT
    )

    await message.answer(
        f"✅ <b>Ro'yxatdan o'tdingiz!</b>\n\n"
        f"👤 Ism: {full_name}\n"
        f"📞 Tel: {phone}",
        parse_mode="HTML"
    )

    if next_action == "order":
        await state.clear()
        await message.answer(
            "🛠️ Kerakli xizmat turini tanlang:",
            reply_markup=get_services_keyboard()
        )
        await state.set_state(OrderCreateStates.waiting_service)
    else:
        await state.clear()
        await message.answer("🏠 Asosiy menyu:", reply_markup=get_main_menu_client())


# ─── Order Creation ────────────────────────────────────────────────────────────

@router.message(OrderCreateStates.waiting_service, F.text)
async def order_service(message: Message, state: FSMContext):
    if message.text not in SERVICE_TYPES:
        await message.answer("❌ Iltimos, ro'yxatdan xizmat tanlang:")
        return

    await state.update_data(service_type=message.text)
    await message.answer(
        "📍 Viloyatingizni tanlang:",
        reply_markup=get_regions_keyboard()
    )
    await state.set_state(OrderCreateStates.waiting_region)


@router.message(OrderCreateStates.waiting_region, F.text)
async def order_region(message: Message, state: FSMContext):
    if message.text not in REGIONS:
        await message.answer("❌ Iltimos, ro'yxatdan viloyat tanlang:")
        return

    await state.update_data(region=message.text)
    await message.answer(
        "🏙️ Tumaningizni tanlang:",
        reply_markup=get_districts_keyboard(message.text)
    )
    await state.set_state(OrderCreateStates.waiting_district)


@router.message(OrderCreateStates.waiting_district, F.text)
async def order_district(message: Message, state: FSMContext):
    data = await state.get_data()
    region = data.get("region", "")
    districts = DISTRICTS.get(region, [])

    if message.text not in districts:
        await message.answer("❌ Iltimos, ro'yxatdan tuman tanlang:")
        return

    await state.update_data(district=message.text)
    await message.answer(
        "📝 Muammoingizni yoki buyurtmani tasvirlab bering:",
        reply_markup=get_cancel_keyboard()
    )
    await state.set_state(OrderCreateStates.waiting_description)


@router.message(OrderCreateStates.waiting_description, F.text)
async def order_description(message: Message, state: FSMContext):
    if len(message.text) < 10:
        await message.answer("❌ Iltimos, batafsil yozing (kamida 10 belgi):")
        return

    await state.update_data(description=message.text)
    await message.answer(
        "📸 Muammoingiz rasmini yuboring yoki o'tkazib yuboring:",
        reply_markup=get_skip_keyboard()
    )
    await state.set_state(OrderCreateStates.waiting_photo)


@router.message(OrderCreateStates.waiting_photo, F.photo)
async def order_photo(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    await state.update_data(photo_file_id=photo_id)
    await _show_order_confirm(message, state)


@router.message(OrderCreateStates.waiting_photo, F.text == "⏭️ O'tkazib yuborish")
async def order_skip_photo(message: Message, state: FSMContext):
    await _show_order_confirm(message, state)


async def _show_order_confirm(message: Message, state: FSMContext):
    data = await state.get_data()
    text = (
        f"📋 <b>Buyurtmangizni tasdiqlang:</b>\n\n"
        f"🛠️ Xizmat: {data.get('service_type')}\n"
        f"📍 {data.get('region')}, {data.get('district')}\n"
        f"📝 {data.get('description')}\n"
        f"📸 Rasm: {'Bor' if data.get('photo_file_id') else 'Yo\'q'}"
    )
    await message.answer(text, parse_mode="HTML", reply_markup=get_confirm_keyboard())
    await state.set_state(OrderCreateStates.confirm)


@router.message(OrderCreateStates.confirm, F.text == "✅ Tasdiqlash")
async def order_confirm(message: Message, state: FSMContext, repo: Repositories, db_user=None):
    data = await state.get_data()

    # Buyurtma yaratish
    order = await repo.orders.create(
        client_id=db_user.id,
        service_type=data.get("service_type"),
        region=data.get("region"),
        district=data.get("district"),
        description=data.get("description"),
        photo_file_id=data.get("photo_file_id"),
    )

    await state.clear()
    await message.answer(
        f"✅ <b>Buyurtma #{order.id} yaratildi!</b>\n\n"
        f"Yaqin atrofdagi ustalar xabardor qilindi.\n"
        f"Tez orada usta siz bilan bog'lanadi. ⏳",
        parse_mode="HTML",
        reply_markup=get_main_menu_client()
    )

    # Tegishli ustalarga xabar yuborish
    from aiogram import Bot
    from aiogram.types import TelegramObject
    bot: Bot = message.bot
    notification_service = NotificationService(bot)

    masters = await repo.masters.get_approved_by_service_region(
        service_type=order.service_type,
        region=order.region,
        district=order.district,
    )

    if masters:
        # Order'ni to'liq ma'lumotlar bilan qaytadan olish
        full_order = await repo.orders.get_by_id(order.id)
        await notification_service.notify_masters_new_order(full_order, masters)
    else:
        await message.answer(
            "⚠️ Hozircha hududingizda mos usta topilmadi.\n"
            "Usta topilishi bilan xabar beriladi."
        )


# ─── Order History ─────────────────────────────────────────────────────────────

@router.message(F.text == "📜 Buyurtmalarim")
async def my_orders(message: Message, repo: Repositories, db_user=None):
    if not db_user:
        await message.answer("❌ Avval ro'yxatdan o'ting!")
        return

    orders = await repo.orders.get_by_client(db_user.id)
    if not orders:
        await message.answer("📭 Sizda hali buyurtmalar yo'q.")
        return

    from keyboards.inline import get_orders_list_keyboard
    await message.answer(
        f"📜 <b>Sizning buyurtmalaringiz ({len(orders)} ta):</b>",
        parse_mode="HTML",
        reply_markup=get_orders_list_keyboard(list(orders))
    )
