import logging

from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from config import config
from database.models import UserRole
from database.repositories import Repositories
from keyboards.reply import (
    get_main_menu_client, get_main_menu_master, get_main_menu_admin
)

logger = logging.getLogger(__name__)
router = Router()


def get_menu_keyboard(user):
    if user and user.telegram_id in config.bot.admin_ids:
        return get_main_menu_admin()
    if user and user.role == UserRole.MASTER:
        return get_main_menu_master()
    return get_main_menu_client()


@router.message(CommandStart())
async def cmd_start(message: Message, repo: Repositories, state: FSMContext, db_user=None):
    await state.clear()

    if not db_user:
        db_user = await repo.users.create(
            telegram_id=message.from_user.id,
            full_name=message.from_user.full_name,
            username=message.from_user.username,
        )

    is_admin = message.from_user.id in config.bot.admin_ids
    if is_admin and db_user.role != UserRole.ADMIN:
        await repo.users.update(message.from_user.id, role=UserRole.ADMIN)

    welcome_text = (
        f"👋 Assalomu alaykum, <b>{message.from_user.first_name}</b>!\n\n"
        f"🏠 <b>{config.bot.name}</b> botiga xush kelibsiz!\n\n"
        f"Bu bot orqali siz:\n"
        f"• 🔍 O'z hududingizda usta topishingiz\n"
        f"• 📋 Buyurtma berishingiz\n"
        f"• 🔧 Usta sifatida ro'yxatdan o'tishingiz mumkin"
    )

    await message.answer(
        welcome_text,
        parse_mode="HTML",
        reply_markup=get_menu_keyboard(db_user)
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        f"ℹ️ <b>{config.bot.name} - Yordam</b>\n\n"
        f"📋 <b>Buyurtma berish</b> - Hududingizda usta toping\n"
        f"🔧 <b>Usta bo'lish</b> - Usta sifatida ro'yxatdan o'ting\n"
        f"📜 <b>Buyurtmalarim</b> - Buyurtmalar tarixingiz\n\n"
        f"📞 Murojaat: {config.bot.support_username}",
        parse_mode="HTML"
    )


@router.message(F.text == "ℹ️ Ma'lumot")
async def info_handler(message: Message):
    await message.answer(
        f"ℹ️ <b>{config.bot.name} haqida</b>\n\n"
        f"Bu bot orqali siz hududingizdagi professional ustalarni topa olasiz.\n\n"
        f"🛠️ Xizmat turlari: Elektrik, Santexnik, Qurilish va ko'p boshqa\n"
        f"📍 Qamrov: Butun O'zbekiston\n\n"
        f"📞 Yordam: {config.bot.support_username}",
        parse_mode="HTML"
    )


@router.message(F.text == "◀️ Orqaga")
async def back_handler(message: Message, state: FSMContext, db_user=None):
    await state.clear()
    await message.answer(
        "🏠 Asosiy menyu",
        reply_markup=get_menu_keyboard(db_user)
    )


@router.message(F.text == "❌ Bekor qilish")
async def cancel_handler(message: Message, state: FSMContext, db_user=None):
    await state.clear()
    await message.answer(
        "❌ Bekor qilindi. Asosiy menyu:",
        reply_markup=get_menu_keyboard(db_user)
    )
