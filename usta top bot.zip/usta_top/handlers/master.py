import logging

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from config import REGIONS, DISTRICTS, SERVICE_TYPES
from database.models import UserRole, OrderStatus
from database.repositories import Repositories
from keyboards.reply import (
    get_phone_keyboard, get_regions_keyboard, get_districts_keyboard,
    get_services_keyboard, get_skip_keyboard, get_cancel_keyboard,
    get_main_menu_master, get_confirm_keyboard
)
from keyboards.inline import get_orders_list_keyboard, get_client_contact_keyboard
from services.notification import NotificationService
from states.states import MasterRegisterStates
from utils.formatters import format_master_profile, format_order_info

logger = logging.getLogger(__name__)
router = Router()


# ─── Master Registration ───────────────────────────────────────────────────────

@router.message(F.text == "🔧 Usta bo'lish")
async def become_master(message: Message, state: FSMContext, db_user=None):
    if db_user and db_user.role == UserRole.MASTER:
        await message.answer(
            "✅ Siz allaqachon usta sifatida ro'yxatdan o'tgansiz!",
            reply_markup=get_main_menu_master()
        )
        return

    await message.answer(
        "🔧 <b>Usta sifatida ro'yxatdan o'tish</b>\n\n"
        "Ismingizni kiriting:",
        parse_mode="HTML",
        reply_markup=get_cancel_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_name)


@router.message(MasterRegisterStates.waiting_name, F.text)
async def master_name(message: Message, state: FSMContext):
    if len(message.text) < 2:
        await message.answer("❌ Iltimos, to'g'ri ism kiriting:")
        return
    await state.update_data(full_name=message.text.strip())
    await message.answer(
        "📱 Telefon raqamingizni yuboring:",
        reply_markup=get_phone_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_phone)


@router.message(MasterRegisterStates.waiting_phone, F.contact)
async def master_phone_contact(message: Message, state: FSMContext):
    phone = message.contact.phone_number
    if not phone.startswith("+"):
        phone = "+" + phone
    await _master_save_phone(message, state, phone)


@router.message(MasterRegisterStates.waiting_phone, F.text)
async def master_phone_text(message: Message, state: FSMContext):
    phone = message.text.strip()
    if not phone.replace("+", "").replace(" ", "").isdigit() or len(phone) < 9:
        await message.answer("❌ Noto'g'ri raqam! Qaytadan kiriting:")
        return
    await _master_save_phone(message, state, phone)


async def _master_save_phone(message: Message, state: FSMContext, phone: str):
    await state.update_data(phone=phone)
    await message.answer(
        "🛠️ Qaysi xizmatni ko'rsatasiz?",
        reply_markup=get_services_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_service)


@router.message(MasterRegisterStates.waiting_service, F.text)
async def master_service(message: Message, state: FSMContext):
    if message.text not in SERVICE_TYPES:
        await message.answer("❌ Iltimos, ro'yxatdan xizmat tanlang:")
        return
    await state.update_data(service_type=message.text)
    await message.answer(
        "📍 Viloyatingizni tanlang:",
        reply_markup=get_regions_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_region)


@router.message(MasterRegisterStates.waiting_region, F.text)
async def master_region(message: Message, state: FSMContext):
    if message.text not in REGIONS:
        await message.answer("❌ Iltimos, ro'yxatdan viloyat tanlang:")
        return
    await state.update_data(region=message.text)
    await message.answer(
        "🏙️ Tumaningizni tanlang:",
        reply_markup=get_districts_keyboard(message.text)
    )
    await state.set_state(MasterRegisterStates.waiting_district)


@router.message(MasterRegisterStates.waiting_district, F.text)
async def master_district(message: Message, state: FSMContext):
    data = await state.get_data()
    districts = DISTRICTS.get(data.get("region", ""), [])
    if message.text not in districts:
        await message.answer("❌ Iltimos, ro'yxatdan tuman tanlang:")
        return
    await state.update_data(district=message.text)
    await message.answer(
        "⏱️ Tajribangizni kiriting (masalan: 5 yil, 2 yil):",
        reply_markup=get_skip_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_experience)


@router.message(MasterRegisterStates.waiting_experience, F.text)
async def master_experience(message: Message, state: FSMContext):
    if message.text == "⏭️ O'tkazib yuborish":
        await state.update_data(experience=None)
    else:
        await state.update_data(experience=message.text.strip())

    await message.answer(
        "💰 Xizmat narxini kiriting (masalan: 50000-200000):\n"
        "Yoki o'tkazib yuboring:",
        reply_markup=get_skip_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_price)


@router.message(MasterRegisterStates.waiting_price, F.text)
async def master_price(message: Message, state: FSMContext):
    price_from = None
    price_to = None

    if message.text != "⏭️ O'tkazib yuborish":
        try:
            parts = message.text.replace(" ", "").split("-")
            if len(parts) == 2:
                price_from = float(parts[0])
                price_to = float(parts[1])
            else:
                price_from = float(parts[0])
        except ValueError:
            await message.answer("❌ Noto'g'ri format. Masalan: 50000-200000 yoki o'tkazib yuboring:")
            return

    await state.update_data(price_from=price_from, price_to=price_to)
    await message.answer(
        "📝 O'zingiz haqida qisqacha ma'lumot kiriting:",
        reply_markup=get_skip_keyboard()
    )
    await state.set_state(MasterRegisterStates.waiting_description)


@router.message(MasterRegisterStates.waiting_description, F.text)
async def master_description(message: Message, state: FSMContext, repo: Repositories):
    description = None if message.text == "⏭️ O'tkazib yuborish" else message.text.strip()
    data = await state.get_data()

    # Foydalanuvchini yangilash
    await repo.users.update(
        message.from_user.id,
        full_name=data.get("full_name"),
        phone=data.get("phone"),
        role=UserRole.MASTER,
    )

    db_user = await repo.users.get_by_telegram_id(message.from_user.id)

    # Master profil yaratish
    master = await repo.masters.create(
        user_id=db_user.id,
        service_type=data.get("service_type"),
        region=data.get("region"),
        district=data.get("district"),
        experience=data.get("experience"),
        price_from=data.get("price_from"),
        price_to=data.get("price_to"),
        description=description,
    )

    await state.clear()
    await message.answer(
        f"✅ <b>Ariza yuborildi!</b>\n\n"
        f"Profilingiz admin tomonidan ko'rib chiqiladi.\n"
        f"Tasdiqlangandan so'ng buyurtmalar olishingiz mumkin bo'ladi. ⏳",
        parse_mode="HTML",
        reply_markup=get_main_menu_master()
    )

    # Adminga xabar yuborish
    full_master = await repo.masters.get_by_id(master.id)
    notification_service = NotificationService(message.bot)
    await notification_service.notify_admins_new_master(full_master)


# ─── Master Dashboard ──────────────────────────────────────────────────────────

@router.message(F.text == "👤 Profilim")
async def master_profile(message: Message, repo: Repositories, db_user=None):
    if not db_user or db_user.role != UserRole.MASTER:
        await message.answer("❌ Siz usta sifatida ro'yxatdan o'tmagansiz!")
        return

    master = await repo.masters.get_by_user_id(db_user.id)
    if not master:
        await message.answer("❌ Profil topilmadi.")
        return

    await message.answer(
        format_master_profile(master),
        parse_mode="HTML"
    )


@router.message(F.text == "📋 Buyurtmalar")
async def master_orders(message: Message, repo: Repositories, db_user=None):
    if not db_user or db_user.role != UserRole.MASTER:
        await message.answer("❌ Faqat ustalar uchun!")
        return

    master = await repo.masters.get_by_user_id(db_user.id)
    if not master:
        return

    orders = await repo.orders.get_by_master(master.id)
    if not orders:
        await message.answer("📭 Sizda hali buyurtmalar yo'q.")
        return

    await message.answer(
        f"📋 <b>Sizning buyurtmalaringiz ({len(orders)} ta):</b>",
        parse_mode="HTML",
        reply_markup=get_orders_list_keyboard(list(orders))
    )


@router.message(F.text == "📊 Statistika")
async def master_stats(message: Message, repo: Repositories, db_user=None):
    if not db_user or db_user.role != UserRole.MASTER:
        return

    master = await repo.masters.get_by_user_id(db_user.id)
    if not master:
        return

    orders = await repo.orders.get_by_master(master.id)
    total = len(orders)
    completed = sum(1 for o in orders if o.status == OrderStatus.COMPLETED)
    active = sum(1 for o in orders if o.status in [OrderStatus.ACCEPTED, OrderStatus.IN_PROGRESS])

    await message.answer(
        f"📊 <b>Sizning statistikangiz</b>\n\n"
        f"📦 Jami buyurtmalar: <b>{total}</b>\n"
        f"✔️ Bajarilgan: <b>{completed}</b>\n"
        f"🔧 Faol: <b>{active}</b>\n"
        f"⭐ Reyting: <b>{master.rating:.1f}</b>",
        parse_mode="HTML"
    )


# ─── Order Accept Callback ─────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("accept_order:"))
async def accept_order(callback: CallbackQuery, repo: Repositories, db_user=None):
    parts = callback.data.split(":")
    order_id = int(parts[1])
    master_id = int(parts[2])

    order = await repo.orders.get_by_id(order_id)
    if not order:
        await callback.answer("❌ Buyurtma topilmadi!", show_alert=True)
        return

    if order.status != OrderStatus.PENDING:
        await callback.answer("⚠️ Bu buyurtma allaqachon qabul qilingan!", show_alert=True)
        return

    await repo.orders.update_status(order_id, OrderStatus.ACCEPTED, master_id)

    # Master'ni olish
    master = await repo.masters.get_by_id(master_id)
    if master:
        await repo.masters.update(master_id, total_orders=master.total_orders + 1)

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        f"✅ <b>Buyurtma #{order_id} qabul qilindi!</b>\n\n"
        f"Mijoz ma'lumotlari:",
        parse_mode="HTML"
    )

    # Mijoz bilan bog'lanish tugmasi
    full_order = await repo.orders.get_by_id(order_id)
    if full_order and full_order.client:
        await callback.message.answer(
            f"👤 {full_order.client.full_name}\n📞 {full_order.client.phone or 'Raqam yo\'q'}",
            reply_markup=get_client_contact_keyboard(
                full_order.client.telegram_id,
                full_order.client.phone or ""
            )
        )

    # Mijozga xabar yuborish
    notification_service = NotificationService(callback.bot)
    await notification_service.notify_client_order_accepted(full_order)
    await callback.answer()


# ─── View Order Callback ───────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("view_order:"))
async def view_order(callback: CallbackQuery, repo: Repositories, db_user=None):
    order_id = int(callback.data.split(":")[1])
    order = await repo.orders.get_by_id(order_id)

    if not order:
        await callback.answer("❌ Buyurtma topilmadi!", show_alert=True)
        return

    is_master = db_user and db_user.role == UserRole.MASTER
    text = format_order_info(order, show_client=is_master, show_master=True)

    if order.photo_file_id:
        await callback.message.answer_photo(
            photo=order.photo_file_id,
            caption=text,
            parse_mode="HTML"
        )
    else:
        await callback.message.answer(text, parse_mode="HTML")

    await callback.answer()
