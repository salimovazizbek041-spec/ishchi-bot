from keyboards.reply import (
    get_remove_keyboard, get_main_menu_client, get_main_menu_master,
    get_main_menu_admin, get_phone_keyboard, get_regions_keyboard,
    get_districts_keyboard, get_services_keyboard, get_skip_keyboard,
    get_confirm_keyboard, get_cancel_keyboard
)
from keyboards.inline import (
    get_master_approval_keyboard, get_order_actions_keyboard,
    get_master_contact_keyboard, get_client_contact_keyboard,
    get_order_status_keyboard, get_orders_list_keyboard,
    get_admin_panel_keyboard, get_services_admin_keyboard,
    get_pending_masters_keyboard
)

__all__ = [
    "get_remove_keyboard", "get_main_menu_client", "get_main_menu_master",
    "get_main_menu_admin", "get_phone_keyboard", "get_regions_keyboard",
    "get_districts_keyboard", "get_services_keyboard", "get_skip_keyboard",
    "get_confirm_keyboard", "get_cancel_keyboard",
    "get_master_approval_keyboard", "get_order_actions_keyboard",
    "get_master_contact_keyboard", "get_client_contact_keyboard",
    "get_order_status_keyboard", "get_orders_list_keyboard",
    "get_admin_panel_keyboard", "get_services_admin_keyboard",
    "get_pending_masters_keyboard",
]
