from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import Sequence

from database.models import Master, Order, ServiceType


def get_master_approval_keyboard(master_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data=f"approve_master:{master_id}")
    builder.button(text="❌ Rad etish", callback_data=f"reject_master:{master_id}")
    builder.adjust(2)
    return builder.as_markup()


def get_order_actions_keyboard(order_id: int, master_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Qabul qilish", callback_data=f"accept_order:{order_id}:{master_id}")
    builder.adjust(1)
    return builder.as_markup()


def get_master_contact_keyboard(master_telegram_id: int, phone: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💬 Usta bilan bog'lanish",
        url=f"tg://user?id={master_telegram_id}"
    )
    builder.button(text=f"📞 {phone}", url=f"tel:{phone}")
    builder.adjust(1)
    return builder.as_markup()


def get_client_contact_keyboard(client_telegram_id: int, phone: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💬 Mijoz bilan bog'lanish",
        url=f"tg://user?id={client_telegram_id}"
    )
    builder.button(text=f"📞 {phone}", url=f"tel:{phone}")
    builder.adjust(1)
    return builder.as_markup()


def get_order_status_keyboard(order_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Bajarildi", callback_data=f"complete_order:{order_id}")
    builder.button(text="❌ Bekor qilish", callback_data=f"cancel_order:{order_id}")
    builder.adjust(2)
    return builder.as_markup()


def get_orders_list_keyboard(orders: list, page: int = 0) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    per_page = 5
    start = page * per_page
    end = start + per_page

    for order in orders[start:end]:
        status_emoji = {
            "pending": "⏳",
            "accepted": "✅",
            "in_progress": "🔧",
            "completed": "✔️",
            "cancelled": "❌",
        }.get(order.status.value, "❓")
        builder.button(
            text=f"{status_emoji} #{order.id} - {order.service_type[:20]}",
            callback_data=f"view_order:{order.id}"
        )

    nav_buttons = []
    if page > 0:
        nav_buttons.append(
            InlineKeyboardButton(text="◀️", callback_data=f"orders_page:{page-1}")
        )
    if end < len(orders):
        nav_buttons.append(
            InlineKeyboardButton(text="▶️", callback_data=f"orders_page:{page+1}")
        )

    builder.adjust(1)
    if nav_buttons:
        builder.row(*nav_buttons)

    return builder.as_markup()


def get_admin_panel_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="⏳ Kutayotgan ustalar", callback_data="admin:pending_masters")
    builder.button(text="👥 Foydalanuvchilar", callback_data="admin:users")
    builder.button(text="📊 Statistika", callback_data="admin:stats")
    builder.button(text="🛠️ Xizmat turlari", callback_data="admin:services")
    builder.button(text="📢 Reklama yuborish", callback_data="admin:broadcast")
    builder.button(text="🚫 Foydalanuvchi bloklash", callback_data="admin:block_user")
    builder.adjust(2)
    return builder.as_markup()


def get_services_admin_keyboard(services: Sequence[ServiceType]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for service in services:
        status = "✅" if service.is_active else "❌"
        builder.button(
            text=f"{status} {service.name}",
            callback_data=f"toggle_service:{service.id}:{1 if not service.is_active else 0}"
        )
    builder.button(text="➕ Yangi xizmat", callback_data="admin:add_service")
    builder.button(text="◀️ Orqaga", callback_data="admin:back")
    builder.adjust(1)
    return builder.as_markup()


def get_pending_masters_keyboard(masters: Sequence[Master]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for master in masters:
        builder.button(
            text=f"👤 {master.user.full_name} - {master.service_type[:15]}",
            callback_data=f"view_master:{master.id}"
        )
    builder.button(text="◀️ Orqaga", callback_data="admin:back")
    builder.adjust(1)
    return builder.as_markup()
