from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from config import REGIONS, DISTRICTS, SERVICE_TYPES


def get_remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()


def get_main_menu_client() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="📋 Buyurtma berish")
    builder.button(text="📜 Buyurtmalarim")
    builder.button(text="🔧 Usta bo'lish")
    builder.button(text="ℹ️ Ma'lumot")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_main_menu_master() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="📋 Buyurtmalar")
    builder.button(text="👤 Profilim")
    builder.button(text="📊 Statistika")
    builder.button(text="ℹ️ Ma'lumot")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_main_menu_admin() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="👮 Admin panel")
    builder.button(text="📋 Buyurtma berish")
    builder.button(text="📊 Statistika")
    builder.button(text="📢 Reklama")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_phone_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="📱 Telefon raqamni yuborish", request_contact=True)
    builder.button(text="◀️ Orqaga")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)


def get_regions_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for region in REGIONS:
        builder.button(text=region)
    builder.button(text="◀️ Orqaga")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_districts_keyboard(region: str) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    districts = DISTRICTS.get(region, [])
    for district in districts:
        builder.button(text=district)
    builder.button(text="◀️ Orqaga")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_services_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for service in SERVICE_TYPES:
        builder.button(text=service)
    builder.button(text="◀️ Orqaga")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_skip_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="⏭️ O'tkazib yuborish")
    builder.button(text="◀️ Orqaga")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_confirm_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash")
    builder.button(text="❌ Bekor qilish")
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True)


def get_cancel_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="❌ Bekor qilish")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)
