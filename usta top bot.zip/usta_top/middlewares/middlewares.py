import logging
from typing import Callable, Dict, Any, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message

from database.connection import async_session_maker
from database.repositories import Repositories

logger = logging.getLogger(__name__)


class DatabaseMiddleware(BaseMiddleware):
    """Har bir handler'ga database session va repository inject qiladi."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        async with async_session_maker() as session:
            data["session"] = session
            data["repo"] = Repositories(session)
            try:
                result = await handler(event, data)
                return result
            except Exception as e:
                await session.rollback()
                logger.error(f"Database middleware error: {e}", exc_info=True)
                raise


class BlockedUserMiddleware(BaseMiddleware):
    """Bloklangan foydalanuvchilarni filtrlaydi."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        repo: Repositories = data.get("repo")
        if not repo:
            return await handler(event, data)

        user = data.get("event_from_user")
        if not user:
            return await handler(event, data)

        db_user = await repo.users.get_by_telegram_id(user.id)
        if db_user and db_user.is_blocked:
            if isinstance(event, Message):
                await event.answer(
                    "❌ Siz bloklangansiz. Murojaat uchun: @support"
                )
            return

        data["db_user"] = db_user
        return await handler(event, data)


class LoggingMiddleware(BaseMiddleware):
    """Barcha so'rovlarni logga yozadi."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user:
            logger.info(
                f"User {user.id} ({user.username or user.full_name}) -> "
                f"{type(event).__name__}"
            )
        return await handler(event, data)
