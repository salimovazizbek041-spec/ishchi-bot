import logging
from typing import Optional, Sequence

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest

from config import config
from database.models import Master, Order, User
from keyboards.inline import (
    get_master_approval_keyboard, get_order_actions_keyboard,
    get_client_contact_keyboard
)
from utils.formatters import format_master_profile, format_order_info

logger = logging.getLogger(__name__)


class NotificationService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def notify_admins_new_master(self, master: Master):
        """Admin(lar)ga yangi usta haqida xabar yuborish."""
        text = (
            f"🆕 <b>Yangi usta ro'yxatdan o'tdi!</b>\n\n"
            f"{format_master_profile(master)}"
        )
        for admin_id in config.bot.admin_ids:
            try:
                await self.bot.send_message(
                    chat_id=admin_id,
                    text=text,
                    parse_mode="HTML",
                    reply_markup=get_master_approval_keyboard(master.id)
                )
            except Exception as e:
                logger.error(f"Failed to notify admin {admin_id}: {e}")

    async def notify_master_approved(self, master: Master):
        """Ustaga tasdiqlanganligi haqida xabar."""
        try:
            await self.bot.send_message(
                chat_id=master.user.telegram_id,
                text=(
                    f"🎉 <b>Tabriklaymiz!</b>\n\n"
                    f"Sizning ustalik profilingiz tasdiqlandi.\n"
                    f"Endi siz buyurtmalar olishingiz mumkin! ✅"
                ),
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Failed to notify master {master.user.telegram_id}: {e}")

    async def notify_master_rejected(self, master: Master):
        """Ustaga rad etilganligi haqida xabar."""
        try:
            await self.bot.send_message(
                chat_id=master.user.telegram_id,
                text=(
                    f"❌ <b>Kechirasiz!</b>\n\n"
                    f"Sizning profilingiz tasdiqlanmadi.\n"
                    f"Murojaat uchun: {config.bot.support_username}"
                ),
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Failed to notify master {master.user.telegram_id}: {e}")

    async def notify_masters_new_order(self, order: Order, masters: Sequence[Master]):
        """Tegishli ustalarga yangi buyurtma haqida xabar."""
        text = (
            f"🔔 <b>Yangi buyurtma keldi!</b>\n\n"
            f"{format_order_info(order, show_master=False)}"
        )
        for master in masters:
            try:
                if order.photo_file_id:
                    await self.bot.send_photo(
                        chat_id=master.user.telegram_id,
                        photo=order.photo_file_id,
                        caption=text,
                        parse_mode="HTML",
                        reply_markup=get_order_actions_keyboard(order.id, master.id)
                    )
                else:
                    await self.bot.send_message(
                        chat_id=master.user.telegram_id,
                        text=text,
                        parse_mode="HTML",
                        reply_markup=get_order_actions_keyboard(order.id, master.id)
                    )
            except (TelegramForbiddenError, TelegramBadRequest) as e:
                logger.warning(f"Cannot notify master {master.user.telegram_id}: {e}")
            except Exception as e:
                logger.error(f"Error notifying master {master.user.telegram_id}: {e}")

    async def notify_client_order_accepted(self, order: Order):
        """Mijozga buyurtmasi qabul qilinganligi haqida xabar."""
        if not order.master:
            return
        try:
            await self.bot.send_message(
                chat_id=order.client.telegram_id,
                text=(
                    f"✅ <b>Buyurtmangiz qabul qilindi!</b>\n\n"
                    f"📋 Buyurtma #{order.id}\n"
                    f"🔧 Usta: {order.master.user.full_name}\n\n"
                    f"Usta siz bilan tez orada bog'lanadi."
                ),
                parse_mode="HTML",
                reply_markup=get_client_contact_keyboard(
                    order.master.user.telegram_id,
                    order.master.user.phone or ""
                )
            )
        except Exception as e:
            logger.error(f"Failed to notify client {order.client.telegram_id}: {e}")

    async def broadcast(self, users: Sequence[User], text: str,
                        photo_file_id: Optional[str] = None) -> tuple[int, int]:
        """Barcha foydalanuvchilarga xabar yuborish. Returns (sent, failed)."""
        sent = 0
        failed = 0
        for user in users:
            try:
                if photo_file_id:
                    await self.bot.send_photo(
                        chat_id=user.telegram_id,
                        photo=photo_file_id,
                        caption=text,
                        parse_mode="HTML"
                    )
                else:
                    await self.bot.send_message(
                        chat_id=user.telegram_id,
                        text=text,
                        parse_mode="HTML"
                    )
                sent += 1
            except (TelegramForbiddenError, TelegramBadRequest):
                failed += 1
            except Exception as e:
                logger.error(f"Broadcast error for {user.telegram_id}: {e}")
                failed += 1
        return sent, failed
