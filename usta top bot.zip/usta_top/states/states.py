from aiogram.fsm.state import State, StatesGroup


class ClientRegisterStates(StatesGroup):
    waiting_name = State()
    waiting_phone = State()
    waiting_region = State()
    waiting_district = State()


class MasterRegisterStates(StatesGroup):
    waiting_name = State()
    waiting_phone = State()
    waiting_service = State()
    waiting_region = State()
    waiting_district = State()
    waiting_experience = State()
    waiting_price = State()
    waiting_description = State()


class OrderCreateStates(StatesGroup):
    waiting_service = State()
    waiting_region = State()
    waiting_district = State()
    waiting_description = State()
    waiting_photo = State()
    confirm = State()


class AdminStates(StatesGroup):
    waiting_broadcast_text = State()
    waiting_broadcast_photo = State()
    waiting_service_name = State()
    waiting_block_user_id = State()
