from datetime import datetime
from typing import Optional

from database.models import User, Master, Order, MasterStatus, OrderStatus


def format_user_info(user: User) -> str:
    role_emoji = {"client": "👤", "master": "🔧", "admin": "👮"}.get(user.role.value, "👤")
    blocked = " 🚫" if user.is_blocked else ""
    return (
        f"{role_emoji} <b>{user.full_name}</b>{blocked}\n"
        f"📱 {user.phone or 'Kiritilmagan'}\n"
        f"🆔 ID: <code>{user.telegram_id}</code>\n"
        f"📍 {user.region or '-'}, {user.district or '-'}\n"
        f"📅 {user.created_at.strftime('%d.%m.%Y')}"
    )


def format_master_profile(master: Master) -> str:
    status_map = {
        MasterStatus.PENDING: "⏳ Tasdiqlanmagan",
        MasterStatus.APPROVED: "✅ Tasdiqlangan",
        MasterStatus.BLOCKED: "🚫 Bloklangan",
    }
    price_text = ""
    if master.price_from and master.price_to:
        price_text = f"💰 Narx: {master.price_from:,.0f} - {master.price_to:,.0f} so'm"
    elif master.price_from:
        price_text = f"💰 Narxdan: {master.price_from:,.0f} so'm"

    return (
        f"🔧 <b>{master.user.full_name}</b>\n"
        f"📞 {master.user.phone or 'Kiritilmagan'}\n"
        f"🛠️ Xizmat: {master.service_type}\n"
        f"📍 {master.region}, {master.district}\n"
        f"⏱️ Tajriba: {master.experience or 'Ko\'rsatilmagan'}\n"
        f"{price_text}\n"
        f"⭐ Reyting: {master.rating:.1f}\n"
        f"📦 Buyurtmalar: {master.total_orders}\n"
        f"📊 Holat: {status_map.get(master.status, '❓')}\n"
        f"📅 Ro'yxat: {master.created_at.strftime('%d.%m.%Y')}"
    )


def format_order_info(order: Order, show_client: bool = True, show_master: bool = True) -> str:
    status_map = {
        OrderStatus.PENDING: "⏳ Kutilmoqda",
        OrderStatus.ACCEPTED: "✅ Qabul qilindi",
        OrderStatus.IN_PROGRESS: "🔧 Bajarilmoqda",
        OrderStatus.COMPLETED: "✔️ Bajarildi",
        OrderStatus.CANCELLED: "❌ Bekor qilindi",
    }

    text = (
        f"📋 <b>Buyurtma #{order.id}</b>\n"
        f"🛠️ Xizmat: {order.service_type}\n"
        f"📍 {order.region}, {order.district}\n"
        f"📝 {order.description}\n"
        f"📊 Holat: {status_map.get(order.status, '❓')}\n"
        f"📅 {order.created_at.strftime('%d.%m.%Y %H:%M')}"
    )

    if show_client and order.client:
        text += f"\n\n👤 <b>Mijoz:</b> {order.client.full_name}"
        if order.client.phone:
            text += f"\n📞 {order.client.phone}"

    if show_master and order.master:
        text += f"\n\n🔧 <b>Usta:</b> {order.master.user.full_name}"

    return text


def format_stats(
    total_users: int,
    total_masters: int,
    pending_masters: int,
    total_orders: int,
    pending_orders: int,
    completed_orders: int,
) -> str:
    return (
        f"📊 <b>Statistika</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{total_users}</b>\n"
        f"🔧 Jami ustalar: <b>{total_masters}</b>\n"
        f"⏳ Tasdiq kutayotgan ustalar: <b>{pending_masters}</b>\n\n"
        f"📋 Jami buyurtmalar: <b>{total_orders}</b>\n"
        f"⏳ Kutayotgan: <b>{pending_orders}</b>\n"
        f"✔️ Bajarilgan: <b>{completed_orders}</b>"
    )


def chunk_list(lst: list, chunk_size: int) -> list:
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]
